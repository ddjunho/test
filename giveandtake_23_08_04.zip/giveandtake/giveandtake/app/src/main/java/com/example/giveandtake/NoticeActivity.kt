package com.example.giveandtake

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class NoticeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_notice)
        val backspaceImageView: View = findViewById(R.id.backspace)
        backspaceImageView.setOnClickListener {
            onBackPressed()
        }
    }
}