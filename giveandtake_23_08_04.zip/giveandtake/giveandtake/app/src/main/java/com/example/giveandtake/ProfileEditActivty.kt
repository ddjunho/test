package com.example.giveandtake

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class ProfileEditActivty : AppCompatActivity() {
    private lateinit var editTextUsername: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile_edit)

        val backspaceImageView: View = findViewById(R.id.backspace)
        backspaceImageView.setOnClickListener {
            onBackPressed()
        }
        val buttonSelectImage: Button = findViewById(R.id.buttonSelectImage)
        val buttonSave: Button = findViewById(R.id.buttonSave)

        editTextUsername = findViewById(R.id.editTextNickname)
        // 이전에 저장된 사용자 이름을 불러와서 보여줍니다.
        loadUsername()

        // 이미지 선택 버튼 클릭 이벤트 처리
        buttonSelectImage.setOnClickListener {
            showToast("이미지를 선택합니다.")
        }

        // 저장 버튼 클릭 이벤트 처리
        buttonSave.setOnClickListener {
            saveUsername()
            showToast("저장했습니다.")
        }

    }
    // 사용자 이름을 SharedPreferences에 저장
    private fun saveUsername() {
        val username = editTextUsername.text.toString().trim()
        val sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("username", username)
        editor.apply()
    }

    // 저장된 사용자 이름을 불러와서 EditText에 보여줍니다.
    private fun loadUsername() {
        val sharedPreferences = getSharedPreferences("MyPrefs", MODE_PRIVATE)
        val username = sharedPreferences.getString("username", "")
        editTextUsername.setText(username)
    }

    // 메시지를 띄우는 함수
    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }
}
