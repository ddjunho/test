package com.example.giveandtake

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class CheckStudentInfoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_check_student_info)
        val backspaceImageView: View = findViewById(R.id.backspace)
        backspaceImageView.setOnClickListener {
            onBackPressed()
        }
    }
}