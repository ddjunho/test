package com.example.giveandtake

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment

class MenuActivity : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.activity_menu, container, false)

        // Create ImageView
        val createImageView: ImageView = view.findViewById(R.id.create_image_view)
        createImageView.setOnClickListener {
            // 클릭 시 다른 화면으로 이동하는 코드 작성
            val intent = Intent(activity, ProfileEditActivty::class.java)
            startActivity(intent)
        }
    // Transform ImageView
        val transformImageView: ImageView = view.findViewById(R.id.transform_image_view)
        transformImageView.setOnClickListener {
            toggleIncludedViews()
        }

        val myClassTextView: TextView = view.findViewById(R.id.myClassTextView)
        val inquiryTextView: TextView = view.findViewById(R.id.inquiryTextView)
        val noticeTextView: TextView = view.findViewById(R.id.noticeTextView)
        val logoutTextView: TextView = view.findViewById(R.id.logoutTextView)

        val registerLessonTextView: TextView = view.findViewById(R.id.registerLessonTextView)
        val modifyLessonTextView: TextView = view.findViewById(R.id.modifyLessonTextView)
        val checkStudentInfoTextView: TextView = view.findViewById(R.id.checkStudentInfoTextView)
        val calculateLessonTextView: TextView = view.findViewById(R.id.calculateLessonTextView)
        val quitInstructorTextView: TextView = view.findViewById(R.id.quitInstructorTextView)

        myClassTextView.setOnClickListener {
            // Start the activity for "마이 클래스"
            val intent = Intent(activity, MyClassActivity::class.java)
            startActivity(intent)
        }

        inquiryTextView.setOnClickListener {
            // Start the activity for "문의 하기"
            val intent = Intent(activity, InquiryActivity::class.java)
            startActivity(intent)
        }

        noticeTextView.setOnClickListener {
            // Start the activity for "공지사항"
            val intent = Intent(activity, NoticeActivity::class.java)
            startActivity(intent)
        }

        logoutTextView.setOnClickListener {
            // Perform logout action here (if needed)
            // For example, return to the login screen or clear session data.
            showLogoutConfirmationDialog()
        }
        registerLessonTextView.setOnClickListener {
            // Start the activity for "레슨등록"
            val intent = Intent(activity, RegisterLessonActivity::class.java)
            startActivity(intent)
        }
        modifyLessonTextView.setOnClickListener {
            // Start the activity for "레슨수정"
            val intent = Intent(activity, ModifyLessonActivity::class.java)
            startActivity(intent)
        }
        checkStudentInfoTextView.setOnClickListener {
            // Start the activity for "수강생정보확인"
            val intent = Intent(activity, CheckStudentInfoActivity::class.java)
            startActivity(intent)
        }
        calculateLessonTextView.setOnClickListener {
            // Start the activity for "레슨정산하기"
            val intent = Intent(activity, CalculateLessonActivity::class.java)
            startActivity(intent)
        }
        quitInstructorTextView.setOnClickListener {
            // Start the activity for "강사그만두기"
            val intent = Intent(activity, QuitInstructorActivity::class.java)
            startActivity(intent)
        }
        return view
    }
    private fun showLogoutConfirmationDialog() {
        val alertDialogBuilder = AlertDialog.Builder(requireContext())
        alertDialogBuilder.setTitle("로그아웃")
        alertDialogBuilder.setMessage("정말 로그아웃하시겠습니까?")
        alertDialogBuilder.setPositiveButton("로그아웃") { dialogInterface: DialogInterface, i: Int ->
            // Perform logout action here (if needed)
            // For example, return to the login screen or clear session data.
            // ... (Add your logout code here)
        }
        alertDialogBuilder.setNegativeButton("취소") { dialogInterface: DialogInterface, i: Int ->
            // Do nothing when the "취소" button is clicked
        }
        alertDialogBuilder.show()
    }
    private fun toggleIncludedViews() {
        val instructorView = view?.findViewById<View>(R.id.instructor_menu)
        val profileView = view?.findViewById<View>(R.id.profile_menu)

        if (profileView?.visibility == View.VISIBLE) {
            // Hide profile_menu and show instructor_menu
            profileView.visibility = View.GONE
            instructorView?.visibility = View.VISIBLE
        } else {
            // Hide instructor_menu and show profile_menu
            instructorView?.visibility = View.GONE
            profileView?.visibility = View.VISIBLE
        }
    }


}