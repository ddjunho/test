package com.example.giveandtake

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class ModifyLessonActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_modify_lesson)
        val backspaceImageView: View = findViewById(R.id.backspace)
        backspaceImageView.setOnClickListener {
            onBackPressed()
        }
    }
}