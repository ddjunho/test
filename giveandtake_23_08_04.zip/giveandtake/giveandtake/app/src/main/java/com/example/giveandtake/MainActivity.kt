package com.example.giveandtake

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import com.google.android.material.bottomnavigation.BottomNavigationView

class MainActivity : AppCompatActivity() {
    private var bottomNavigationView: BottomNavigationView? = null
    private var fragmentManager: FragmentManager? = null
    private var fragmentTransaction: FragmentTransaction? = null
    private var chatFragment: ChatActivity? = null
    private var menuFragment: MenuActivity? = null
    private var placeFragment: PlaceActivity? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bottomNavigationView = findViewById(R.id.navigation_bar)
        bottomNavigationView?.setOnItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.home_button -> {
                    showPost()
                    setFragment(null)
                    true
                }
                R.id.chat_button -> {
                    hidePost()
                    setFragment(chatFragment)
                    true
                }
                R.id.lesson_button -> {
                    hidePost()
                    setFragment(placeFragment)
                    true
                }
                R.id.menu_button -> {
                    hidePost()
                    setFragment(menuFragment)
                    true
                }
                else -> false
            }
        }

        chatFragment = ChatActivity()
        menuFragment = MenuActivity()
        placeFragment = PlaceActivity()
    }

    private val includeViewIds = intArrayOf(R.id.top_bar, R.id.activity_main_post, R.id.activity_main_post2)

    private fun showPost() {
        for (id in includeViewIds) {
            val view = findViewById<View>(id)
            view?.visibility = View.VISIBLE
        }
    }

    private fun hidePost() {
        for (id in includeViewIds) {
            val view = findViewById<View>(id)
            view?.visibility = View.GONE
        }
    }

    private fun setFragment(fragment: Fragment?) {
        fragmentManager = supportFragmentManager
        fragmentTransaction = fragmentManager?.beginTransaction()
        val currentFragment = fragmentManager?.findFragmentById(R.id.main_content)
        currentFragment?.let {
            fragmentTransaction?.remove(it)
        }
        if (fragment != null) {
            fragmentTransaction?.replace(R.id.main_content, fragment)
        } else {
            fragmentManager?.popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE)
        }
        fragmentTransaction?.commit()
    }
}
